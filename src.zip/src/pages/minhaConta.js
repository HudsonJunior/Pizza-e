import React from 'react'
import MinhaConta from "../components/minhaContaComponents"

const minhaConta = () =>{
    return(
        <MinhaConta></MinhaConta>
    )
}

export default minhaConta 