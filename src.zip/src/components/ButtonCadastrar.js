
const BotaoCadastrar = () =>{
    <div>
        <p>alo</p>
    </div>
}

export default BotaoCadastrar;