import React, { Component, useEffect, useState } from 'react'

const EditTextUser = () => {
    
    return(
        <div>

        </div>
    );

}

const EditTextSenha = () => {
    
    return(
        <div>

        </div>
    );

}

export default EditTextSenha
