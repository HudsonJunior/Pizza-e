import React from 'react'
import './styles/HeaderStyle.css'

const Header = ()  => {
    return(
    <div className = "boxHeader">
        <h1>Pizza-e</h1>
    </div>
    )
}

export default Header