import React from 'react'
import './styles/HomeStyle.css'

const Home = () =>{
    return(
        <div></div>
    )
}

export default Home