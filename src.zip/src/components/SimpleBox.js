// src/components/BoxSimple.jsx
import React from 'react'
import './styles/SimpleBoxStyle.css'

const SimpleBox = () => {
    return (
        <div>
        </div>
    )
}


export default SimpleBox